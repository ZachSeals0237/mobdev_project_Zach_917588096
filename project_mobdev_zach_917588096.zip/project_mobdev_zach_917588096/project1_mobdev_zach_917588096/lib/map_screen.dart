import 'package:flutter/material.dart';
import 'battery_level.dart'; 
// Username email project1@gmail.com
//password project123
class MapScreen extends StatelessWidget {
  final String username;

  MapScreen({required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Map'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text('Map Screen for $username'), 
          ),
          SizedBox(height: 20), 
          BatteryLevel(), 
        ],
      ),
    );
  }
}