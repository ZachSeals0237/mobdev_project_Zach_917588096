import 'package:flutter/material.dart';
import 'battery_level.dart'; 
// Username email project1@gmail.com
//password project123
class PictureTakingScreen extends StatelessWidget {
  final String username;

  PictureTakingScreen({required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Picture Taking'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text(username)), 
          ),
        ],
      ),
       body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text('Picture Screen'), 
          ),
          SizedBox(height: 20), 
          BatteryLevel(), 
        ],
      ),
    );
  }
}
