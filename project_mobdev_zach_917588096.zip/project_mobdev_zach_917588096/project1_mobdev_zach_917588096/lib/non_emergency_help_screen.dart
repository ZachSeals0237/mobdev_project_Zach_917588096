import 'package:flutter/material.dart';
import 'battery_level.dart'; 
// Username email project1@gmail.com
//password project123
class NonEmergencyHelpScreen extends StatelessWidget {
  final String username;

  NonEmergencyHelpScreen({required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Non-Emergency Help'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text(username)), 
          ),
        ],
      ),
       body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text('Non-Emergency Help'), 
          ),
          SizedBox(height: 20), 
          BatteryLevel(), 
        ],
      ),
    );
  }
}
