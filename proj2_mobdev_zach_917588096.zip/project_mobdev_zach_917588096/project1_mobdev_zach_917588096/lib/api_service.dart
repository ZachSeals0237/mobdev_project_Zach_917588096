import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  final String baseUrl = "http://10.0.2.2:8080/api/v1"; // Update to your backend URL

  // Fetch all breakfasts
  Future<List<dynamic>> getBreakfasts() async {
  final response = await http.get(Uri.parse('$baseUrl/meal/breakfast'));
  print(response.body); // Add this to check the API response
  if (response.statusCode == 200) {
    return jsonDecode(response.body);
  } else {
    throw Exception("Failed to load breakfasts");
  }
}

  // Fetch details for a specific breakfast
  Future<Map<String, dynamic>> getBreakfastDetails(int id) async {
    final response = await http.get(Uri.parse('$baseUrl/meal/breakfast/$id'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception("Failed to load breakfast details");
    }
  }

  // Place an order for a specific breakfast
  Future<void> placeBreakfastOrder(int id, String username) async {
  // Define the endpoint URL
  final url = Uri.parse('$baseUrl/meal/breakfast/$id/order');

  // Build the request body
  final requestBody = {
    'username': username,
  };

  // Make the POST request
  final response = await http.post(
    url,
    headers: {'Content-Type': 'application/json'}, 
    body: jsonEncode(requestBody), 
  );

  // Debugging: Print the response
  print('Placing order for breakfast ID $id at $url');
  print('Response status: ${response.statusCode}');
  print('Response body: ${response.body}');

  // Check if the order was successfully placed
  if (response.statusCode != 201) {
    throw Exception("Failed to place breakfast order. Status: ${response.statusCode}");
  }
}

  Future<void> requestHelp(Map<String, String> helpRequest) async {
  final url = Uri.parse('$baseUrl/help/request'); 
  print('Sending request to: $url'); 
  final response = await http.post(
    url,
    headers: {'Content-Type': 'application/json'}, 
    body: jsonEncode(helpRequest), 
  );

  print('Response Status: ${response.statusCode}'); 
  print('Response Body: ${response.body}'); 

  if (response.statusCode != 201) {
    throw Exception('Failed to send help request: ${response.statusCode}');
  }
}

}
