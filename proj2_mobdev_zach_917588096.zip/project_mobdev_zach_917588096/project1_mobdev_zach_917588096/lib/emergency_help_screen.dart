import 'package:flutter/material.dart';
import 'api_service.dart';
import 'battery_level.dart';

class EmergencyHelpScreen extends StatelessWidget {
  final String username;

  EmergencyHelpScreen({super.key, required this.username});

  final ApiService _apiService = ApiService();
  final TextEditingController _helpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Emergency Help'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text(username)), 
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _helpController,
              decoration: InputDecoration(
                labelText: 'Describe the emergency',
                border: OutlineInputBorder(),
              ),
              maxLines: 4,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final helpRequest = {
                  'requester': 'project1@gmail.com', 
                  'helpType': 'emergency', 
                };

                try {
                  await _apiService.requestHelp(helpRequest); 
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Emergency help request sent!')),
                  );
                  Navigator.pop(context); 
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Failed to send emergency help request.')),
                  );
                }
              },
              child: Text('Submit Emergency Request'),
            ),
          SizedBox(height: 20), 
          BatteryLevel(), 
          ],
        ),
      ),
    );
  }
}
