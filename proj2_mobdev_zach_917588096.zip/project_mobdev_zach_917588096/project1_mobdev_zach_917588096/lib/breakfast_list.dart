import 'package:flutter/material.dart';
import 'breakfast_detail.dart'; // Import the detail page
import 'api_service.dart'; // Import the API service

class BreakfastListPage extends StatefulWidget {
  @override
  _BreakfastListPageState createState() => _BreakfastListPageState();
}

class _BreakfastListPageState extends State<BreakfastListPage> {
  final ApiService _apiService = ApiService(); 
  late Future<List<dynamic>> _breakfasts; 

  @override
  void initState() {
    super.initState();
    _breakfasts = _apiService.getBreakfasts(); 
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Available Breakfasts'),
      ),
      body: FutureBuilder<List<dynamic>>(
        future: _breakfasts,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No breakfasts available.'));
          } else {
            final breakfasts = snapshot.data!;
            return ListView.builder(
              itemCount: breakfasts.length,
              itemBuilder: (context, index) {
                final breakfast = breakfasts[index];
                return ListTile(
                  title: Text(
                    'Breakfast Combo ${breakfast['id']}', 
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    (breakfast['comboItems'] as List<dynamic>).join(', '), 
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BreakfastDetailPage(
                          breakfastId: breakfast['id'],
                        ),
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
