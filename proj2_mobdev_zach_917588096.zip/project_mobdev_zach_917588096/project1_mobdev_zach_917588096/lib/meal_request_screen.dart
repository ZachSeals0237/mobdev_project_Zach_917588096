import 'package:flutter/material.dart';
import 'battery_level.dart';
import 'breakfast_list.dart'; // Import Breakfast List Screen

class MealRequestScreen extends StatelessWidget {
  final String username;

  const MealRequestScreen({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Request Meal'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(username), 
            ),
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text(
              'Meal Request',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 20), 
          ElevatedButton(
            onPressed: () {
              
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => BreakfastListPage()),
              );
            },
            child: Text('Request Breakfast'),
          ),
          SizedBox(height: 20), 
          BatteryLevel(), 
        ],
      ),
    );
  }
}
