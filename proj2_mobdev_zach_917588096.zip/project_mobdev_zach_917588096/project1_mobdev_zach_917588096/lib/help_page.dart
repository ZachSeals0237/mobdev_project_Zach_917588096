import 'package:flutter/material.dart';
import 'api_service.dart'; // Import the API service

class HelpPage extends StatelessWidget {
  final String username;

  HelpPage({required this.username}); 

  final ApiService _apiService = ApiService(); 
  final TextEditingController _helpController = TextEditingController(); 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Request Help'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(username), 
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Input Field
            TextField(
              controller: _helpController,
              decoration: InputDecoration(
                labelText: 'Describe your issue',
                border: OutlineInputBorder(),
              ),
              maxLines: 4, 
            ),
            SizedBox(height: 20), 
            
            ElevatedButton(
              onPressed: () async {
                final helpRequest = {
                  'description': _helpController.text,
                  'username': username,
                };

                try {
                  await _apiService.requestHelp(helpRequest);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Help request sent successfully!')),
                  );

                 
                  _helpController.clear();
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Failed to send help request.')),
                  );
                }
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
