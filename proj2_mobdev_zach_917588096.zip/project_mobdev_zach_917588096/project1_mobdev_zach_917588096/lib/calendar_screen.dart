import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'battery_level.dart';

class CalendarScreen extends StatefulWidget {
  final String username;

  const CalendarScreen({super.key, required this.username});

  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedDay = DateTime.now(); 
  DateTime? _selectedDay; 
  Map<DateTime, List<String>> _events = {}; 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calendar'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(widget.username), 
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          
          TableCalendar(
            focusedDay: _focusedDay,
            firstDay: DateTime.utc(2020, 1, 1), 
            lastDay: DateTime.utc(2100, 12, 31), 
            calendarFormat: CalendarFormat.month, 
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay; 
              });
            },
            eventLoader: (day) {
              
              return _events[day] ?? [];
            },
          ),
          SizedBox(height: 20),

          // Display Selected Day
          if (_selectedDay != null)
            Text(
              'Selected Day: ${_selectedDay?.toLocal().toString().split(' ')[0]}',
              style: TextStyle(fontSize: 18),
            ),

          SizedBox(height: 20),

          // Button to Add Events
          ElevatedButton(
            onPressed: () async {
              await _addEventDialog(context);
            },
            child: Text('Add Event'),
          ),

          SizedBox(height: 20),
          BatteryLevel(), 
        ],
      ),
    );
  }

  Future<void> _addEventDialog(BuildContext context) async {
    final TextEditingController _eventController = TextEditingController();

    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add Event'),
          content: TextField(
            controller: _eventController,
            decoration: InputDecoration(labelText: 'Event Name'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); 
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (_eventController.text.isNotEmpty && _selectedDay != null) {
                  setState(() {
                   
                    if (_events[_selectedDay!] == null) {
                      _events[_selectedDay!] = [];
                    }
                    _events[_selectedDay!]!.add(_eventController.text);
                  });
                }
                Navigator.pop(context); 
              },
              child: Text('Add'),
            ),
          ],
        );
      },
    );
  }
}
