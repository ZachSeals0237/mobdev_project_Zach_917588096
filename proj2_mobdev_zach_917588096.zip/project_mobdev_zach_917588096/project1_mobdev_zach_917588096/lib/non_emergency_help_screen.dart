import 'package:flutter/material.dart';
import 'api_service.dart'; 
import 'battery_level.dart'; 

class NonEmergencyHelpScreen extends StatelessWidget {
  final String username;

NonEmergencyHelpScreen({super.key, required this.username});

  final ApiService _apiService = ApiService(); 
  final TextEditingController _helpController = TextEditingController(); 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Non-Emergency Help'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text(username)), 
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Describe the Issue:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            
            TextField(
              controller: _helpController,
              decoration: InputDecoration(
                labelText: 'Enter non-emergency details',
                border: OutlineInputBorder(),
              ),
              maxLines: 4, 
            ),
            SizedBox(height: 20),
            // Submit button
            ElevatedButton(
              onPressed: () async {
                final helpRequest = {
                  'requester': 'project1@gmail.com', 
                  'helpType': 'emergency', 
                };

                try {
                  await _apiService.requestHelp(helpRequest); 
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Non-Emergency help request sent!')),
                  );
                  Navigator.pop(context); 
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Failed to send non-emergency help request.')),
                  );
                }
              },
              child: Text('Submit Non-Emergency Request'),
            ),
            SizedBox(height: 20),
            BatteryLevel(),
          ],
        ),
      ),
    );
  }
}
