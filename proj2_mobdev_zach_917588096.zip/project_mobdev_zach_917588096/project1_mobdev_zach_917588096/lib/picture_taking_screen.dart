import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

import 'battery_level.dart';

class PictureTakingScreen extends StatefulWidget {
  final String username;

  const PictureTakingScreen({super.key, required this.username});

  @override
  _PictureTakingScreenState createState() => _PictureTakingScreenState();
}

class _PictureTakingScreenState extends State<PictureTakingScreen> {
  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  bool _isCameraInitialized = false;
  String? _imagePath;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    // Get available cameras
    _cameras = await availableCameras();

    if (_cameras!.isNotEmpty) {
      _cameraController = CameraController(
        _cameras![0], 
        ResolutionPreset.medium,
      );

      await _cameraController!.initialize();

      setState(() {
        _isCameraInitialized = true;
      });
    } else {
      print("No cameras available");
    }
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _takePicture() async {
    if (_cameraController != null && _cameraController!.value.isInitialized) {
      final directory = await getApplicationDocumentsDirectory();
      final imagePath = '${directory.path}/${DateTime.now().millisecondsSinceEpoch}.jpg';

      await _cameraController!.takePicture().then((XFile file) {
        file.saveTo(imagePath);
        setState(() {
          _imagePath = imagePath; 
        });
      });

      print("Picture saved at: $imagePath");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Picture Taking'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text(widget.username)), // Display username
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Display the camera preview or a placeholder
          if (_isCameraInitialized && _cameraController != null)
            AspectRatio(
              aspectRatio: _cameraController!.value.aspectRatio,
              child: CameraPreview(_cameraController!),
            )
          else
            Center(
              child: Text('Initializing camera...'),
            ),
          SizedBox(height: 20),
          // Display the last captured image
          if (_imagePath != null)
            Column(
              children: [
                Text('Last Picture Taken:', style: TextStyle(fontSize: 16)),
                SizedBox(height: 10),
                Image.file(
                  File(_imagePath!), 
                  width: 200,
                  height: 200,
                ),
              ],
            ),
          SizedBox(height: 20),
          // Take Picture Button
          ElevatedButton(
            onPressed: _takePicture,
            child: Text('Take Picture'),
          ),
          SizedBox(height: 20), 
          BatteryLevel(), 
        ],
        
      ),
      
    );
  }
}
