import 'package:battery_plus/battery_plus.dart';
import 'package:flutter/material.dart';
// Username email project1@gmail.com
//password project123
class BatteryLevel extends StatefulWidget {
  const BatteryLevel({super.key});

  @override
  _BatteryLevelState createState() => _BatteryLevelState();
}

class _BatteryLevelState extends State<BatteryLevel> {
  int? _batteryLevel;
  final Battery _battery = Battery();

  @override
  void initState() {
    super.initState();
    _getBatteryLevel();
  }

  Future<void> _getBatteryLevel() async {
    final level = await _battery.batteryLevel;
    setState(() {
      _batteryLevel = level;
    });
  }

  @override
  Widget build(BuildContext context) {
    return _batteryLevel == null
        ? CircularProgressIndicator()
        : Text('Battery: $_batteryLevel%');
  }
}
