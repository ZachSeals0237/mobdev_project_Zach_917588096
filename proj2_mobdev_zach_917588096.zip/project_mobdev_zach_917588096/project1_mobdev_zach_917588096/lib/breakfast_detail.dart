import 'package:flutter/material.dart';
import 'api_service.dart'; // Import API Service
import 'battery_level.dart';
class BreakfastDetailPage extends StatelessWidget {
  final int breakfastId;

  BreakfastDetailPage({required this.breakfastId}); 

  final ApiService _apiService = ApiService(); 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Breakfast Details'),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _apiService.getBreakfastDetails(breakfastId), 
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData) {
            return Center(child: Text('No details available.'));
          } else {
            final breakfast = snapshot.data!; 
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Display a title (e.g., "Breakfast Combo")
                  Text(
                    'Breakfast Combo ${breakfast['id']}', 
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),

                  // Display mealType
                  Text(
                    'Meal Type: ${breakfast['mealType'] ?? 'Unknown'}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),

                  // Display combo items
                  Text(
                    'Items: ${(breakfast['comboItems'] as List<dynamic>).join(', ')}',
                    style: TextStyle(fontSize: 16),
                  ),
                  Spacer(),

                  // Add a button to place an order
                  ElevatedButton(
                    
                    onPressed: () async {
                      try {
                       
                        await _apiService.placeBreakfastOrder(breakfastId, 'project1@gmail.com');
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Order placed successfully!')),
                        );
                         Navigator.of(context).pushNamedAndRemoveUntil('/home', (route) => false);
                      } catch (e) {
                        print('Error: $e'); // Debug the exception
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Failed to place order.')),
                        );
                      }
                    },
                    child: Text('Order Now'),
                   
                    
                  ),
                  SizedBox(height: 20), 
                  BatteryLevel(), 
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
