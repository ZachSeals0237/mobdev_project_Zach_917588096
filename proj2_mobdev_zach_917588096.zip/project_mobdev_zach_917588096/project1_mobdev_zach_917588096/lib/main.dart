import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:project1_mobdev_zach_917588096/emergency_help_screen.dart';
import 'login_page.dart';
import 'home_page.dart'; // Import your Home Page
import 'meal_request_screen.dart'; // Import Meal Request Screen

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Project 1',
      theme: ThemeData(
        primarySwatch: Colors.yellow,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginPage(), 
        '/home': (context) => HomePage(username: 'project1@gmail.com',), 
        '/emergency_help': (context) => EmergencyHelpScreen(username: 'project1@gmail.com'),
        '/meal_request': (context) =>
            MealRequestScreen(username: 'project1@gmail.com'), 
      },
    );
  }
}
