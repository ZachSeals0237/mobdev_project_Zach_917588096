import 'package:flutter/material.dart';
import 'emergency_help_screen.dart';
import 'non_emergency_help_screen.dart';
import 'meal_request_screen.dart';
import 'calendar_screen.dart';
import 'picture_taking_screen.dart';
import 'map_screen.dart';
import 'login_page.dart';

// Username email project1@gmail.com
//password project123
class HomePage extends StatelessWidget {
  final String username;
  const HomePage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      drawer: AppDrawer(username: username),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EmergencyHelpScreen(username: username),
                  ),
                );
              },
              child: Text('Emergency Help'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => NonEmergencyHelpScreen(username: username),
                  ),
                );
              },
              child: Text('Non-Emergency Help'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MealRequestScreen(username: username),
                  ),
                );
              },
              child: Text('Request Meal'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CalendarScreen(username: username),
                  ),
                );
              },
              child: Text('Calendar'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PictureTakingScreen(username: username),
                  ),
                );
              },
              child: Text('Picture Taking'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MapPage(username: username),
                  ),
                );
              },
              child: Text('Map'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              },
              child: Text('Logout'),
              style: ElevatedButton.styleFrom(iconColor: Colors.red),
            ),
          ],
        ),
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  final String username;
  const AppDrawer({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.yellow),
            child: Text('Menu'),
          ),
          ListTile(
            title: Text('Emergency Help'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => EmergencyHelpScreen(username: username)),
              );
            },
          ),
          ListTile(
            title: Text('Non-Emergency Help'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => NonEmergencyHelpScreen(username: username)),
              );
            },
          ),
          ListTile(
            title: Text('Request Meal'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MealRequestScreen(username: username)),
              );
            },
          ),
          ListTile(
            title: Text('Calendar'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CalendarScreen(username: username)),
              );
            },
          ),
          ListTile(
            title: Text('Picture Taking'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PictureTakingScreen(username: username)),
              );
            },
          ),
          ListTile(
            title: Text('Map'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MapPage(username: username)),
              );
            },
          ),
          Divider(),
          ListTile(
            title: Text('Logout'),
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}
