import 'package:flutter/material.dart';

import 'battery_level.dart';

class MapPage extends StatelessWidget {
  final String username;

  const MapPage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Google Map'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(username), // Display username in the AppBar
            ),
            
          ),
          SizedBox(height: 20), // Add spacing
          BatteryLevel(), 
        ],
      ),
      body: Center(
        
        child: Padding(
          
          padding: const EdgeInsets.all(16.0),
          
          child: Text(
            "I could not get Google to verify me to get an API key to work. "
            "You can look in the android/app/src/main/AndroidManifest.xml to see that all I was missing was an API key, "
            "but Google would not give it to me.",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
            
          ),
          
        ),
      ),
      
    );
    
  }
}
